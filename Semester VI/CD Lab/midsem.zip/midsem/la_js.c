#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_TOKEN_LEN 256
#define MAX_SYMBOLS 100
#define MAX_ARG_LEN 512

typedef struct {
    char lexeme[100];
    char type[20];
    char argument[MAX_ARG_LEN];
} Symbol;

Symbol symbolTable[MAX_SYMBOLS];
int symbolCount = 0;

const char *keywords[] = {"let", "function", "document", NULL};
const char *functions[] = {
    "ready", "on", "val", "split", "map",
    "filter", "text", "join", "isNaN", NULL
};

int row = 1, col = 0;

int isKeyword(const char *str) {
    for (int i = 0; keywords[i]; i++)
        if (strcmp(str, keywords[i]) == 0)
            return 1;
    return 0;
}

int isFunction(const char *str) {
    for (int i = 0; functions[i]; i++)
        if (strcmp(str, functions[i]) == 0)
            return 1;
    return 0;
}

void addSymbol(const char *lexeme, const char *type, const char *arg) {
    for (int i = 0; i < symbolCount; i++) {
        if (strcmp(symbolTable[i].lexeme, lexeme) == 0)
            return;
    }

    strcpy(symbolTable[symbolCount].lexeme, lexeme);
    strcpy(symbolTable[symbolCount].type, type);
    if (arg)
        strcpy(symbolTable[symbolCount].argument, arg);
    else
        symbolTable[symbolCount].argument[0] = '\0';

    symbolCount++;
}

void printToken(const char *token, int tokenRow, int tokenCol) {
    printf("<%-20s %3d %3d>\n", token, tokenRow, tokenCol);
}

void updatePosition(int c) {
    if (c == '\n') {
        row++;
        col = 0;
    } else {
        col++;
    }
}

void captureArgument(FILE *fp, char *argOut) {
    int c;
    int count = 1;
    int k = 0;

    while ((c = fgetc(fp)) != EOF && k < MAX_ARG_LEN - 1) {
        updatePosition(c);

        if (c == '(') count++;
        else if (c == ')') count--;

        if (count == 0)
            break;

        argOut[k++] = c;
    }

    argOut[k] = '\0';
}

int main() {

    FILE *fp = fopen("input.js", "r");
    if (!fp) {
        printf("Error opening input.js\n");
        return 1;
    }

    int c;

    while ((c = fgetc(fp)) != EOF) {

        updatePosition(c);

        if (isspace(c))
            continue;

        int tokenRow = row;
        int tokenCol = col;

        // Identifier / keyword / function
        if (isalpha(c) || c == '_') {
            char buffer[MAX_TOKEN_LEN];
            int i = 0;

            buffer[i++] = c;

            while ((c = fgetc(fp)) != EOF &&
                   (isalnum(c) || c == '_')) {
                updatePosition(c);
                buffer[i++] = c;
            }

            buffer[i] = '\0';

            if (c != EOF) {
                ungetc(c, fp);
                col--;
            }

            printToken(buffer, tokenRow, tokenCol);

            if (isKeyword(buffer)) {
                continue;
            }
            else if (isFunction(buffer)) {

                if (strcmp(buffer, "ready") == 0) {
                    addSymbol(buffer, "FUNC", NULL);
                }
                else {
                    // Expect '('
                    c = fgetc(fp);
                    updatePosition(c);

                    while (isspace(c)) {
                        c = fgetc(fp);
                        updatePosition(c);
                    }

                    if (c == '(') {
                        char arg[MAX_ARG_LEN];
                        captureArgument(fp, arg);
                        addSymbol(buffer, "FUNC", arg);
                    }
                }
            }
            else {
                addSymbol(buffer, "Identifier", NULL);
            }

            continue;
        }

        // String or "#identifier"
        if (c == '"') {
            char buffer[MAX_TOKEN_LEN];
            int i = 0;

            while ((c = fgetc(fp)) != EOF && c != '"') {
                updatePosition(c);
                buffer[i++] = c;
            }

            buffer[i] = '\0';
            updatePosition(c);

            printToken(buffer, tokenRow, tokenCol);

            if (buffer[0] == '#')
                addSymbol(buffer, "Identifier", NULL);

            continue;
        }

        // Regex /\s+/
        if (c == '/') {
            int next = fgetc(fp);
            updatePosition(next);

            if (next == '\\') {
                char buffer[MAX_TOKEN_LEN];
                int i = 0;

                buffer[i++] = '/';
                buffer[i++] = '\\';

                while ((c = fgetc(fp)) != EOF && c != '/') {
                    updatePosition(c);
                    buffer[i++] = c;
                }

                buffer[i++] = '/';
                buffer[i] = '\0';
                updatePosition(c);

                printToken(buffer, tokenRow, tokenCol);
            }
            else {
                ungetc(next, fp);
                col--;
                printToken("/", tokenRow, tokenCol);
            }

            continue;
        }

        // Multi-character operators
        if (c == '=') {
            int next = fgetc(fp);
            updatePosition(next);

            if (next == '=') {
                printToken("==", tokenRow, tokenCol);
            }
            else if (next == '>') {
                printToken("=>", tokenRow, tokenCol);
            }
            else {
                ungetc(next, fp);
                col--;
                printToken("=", tokenRow, tokenCol);
            }
            continue;
        }

        if (c == '&') {
            int next = fgetc(fp);
            updatePosition(next);

            if (next == '&') {
                printToken("&&", tokenRow, tokenCol);
            }
            continue;
        }

        // Numbers
        if (isdigit(c)) {
            char buffer[MAX_TOKEN_LEN];
            int i = 0;
            buffer[i++] = c;

            while ((c = fgetc(fp)) != EOF && isdigit(c)) {
                updatePosition(c);
                buffer[i++] = c;
            }

            buffer[i] = '\0';

            if (c != EOF) {
                ungetc(c, fp);
                col--;
            }

            printToken(buffer, tokenRow, tokenCol);
            continue;
        }

        // Single-character tokens
        if (strchr("+-*%!?():{}.,;$", c)) {
            char temp[2] = {c, '\0'};
            printToken(temp, tokenRow, tokenCol);
            continue;
        }
    }

    fclose(fp);

    printf("\n================ SYMBOL TABLE ================\n");
    printf("%-20s %-15s %-40s\n", "Lexeme", "Token Type", "Argument");
    printf("--------------------------------------------------------------------------\n");

    for (int i = 0; i < symbolCount; i++) {
        printf("%-20s %-15s %-40s\n",
               symbolTable[i].lexeme,
               symbolTable[i].type,
               symbolTable[i].argument);
    }

    return 0;
}
